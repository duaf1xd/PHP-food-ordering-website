<?php 
if(!isset($_SESSION)){
    session_start();
}
if(!isset($_SESSION['customer_phonenum'])){
    $_SESSION['success']= "Please login to order.";
    header("location: index.php");
    exit;
}

require_once "db/connect.php";

if(isset($_POST['save_ticket'])){
	echo "<p>This is save_ticket</p>";
	$details= $_POST['ticket'];
	$cid= $_SESSION['customer_id'];
    $query = "INSERT INTO request (request_details, customer_id) 
          VALUES('$details', '$cid')";
    mysqli_query($link, $query) or die(mysqli_error($link));

    $query = "UPDATE customer SET unfinished_orders= unfinished_orders+1 WHERE id= $cid";
    mysqli_query($link, $query) or die(mysqli_error($link));

    $_SESSION['status_message'] = "Order created succesfully.";
    header('location: my_order.php');
}
?>