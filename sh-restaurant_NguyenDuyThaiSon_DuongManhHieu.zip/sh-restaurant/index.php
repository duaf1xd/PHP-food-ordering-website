<?php 
if(!isset($_SESSION)){
    session_start();
}
if(isset($_SESSION['success'])){
    echo '<br>';
    echo '<br>';
    echo '<br>';
    echo '<br>';
    echo '<br>';
    echo '<h2>'.$_SESSION['success'].'</h2>';
    unset($_SESSION['success']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>SH Restaurant</title>
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
    <link rel ="stylesheet" href="css/restaurant.css">
</head>
<body>
	<ul>
      <li id="courseman"><a href="index.php">SH Restaurant</a></li>
  		<li><a href="menu.php">Menu</a></li>
  		<li><a href="login.php">Login</a></li>
        <li><a href="create_order.php">Order food now!</a></li>
        <li><a href="my_order.php">Your orders</a></li>
        <?php
        if(isset($_SESSION['loggedin'])){
            echo <<< HERE
            <li id="logout"><a href="logout.php">Logout</a></li>
            HERE;
        }
        ?>
	</ul>
	<div style="padding: 50px"></div>
	<h1>Welcome to SH Restaurant's Website!</h1>
    <h3>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
    </h3>

    <img src="test/hk.jpg">

    <h1>PROMOTIONS</h1>
    <h3>Buy 120 Dasani Watter Bottles and GET ONE AQUAFINA WATER BOTTLE FOR FREE!</h3>
</body>
</html>