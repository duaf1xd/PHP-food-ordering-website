<?php 
if(!isset($_SESSION)){
    session_start();
}

$errors = array(); 

require_once "db/connect.php";

if (isset($_POST['reg_customer'])) {
  $phone_number = mysqli_real_escape_string($link, $_POST['phone_number']);
  $password_1 = mysqli_real_escape_string($link, $_POST['password_1']);
  $password_2 = mysqli_real_escape_string($link, $_POST['password_2']);
  $name = mysqli_real_escape_string($link, $_POST['name']);

  if (empty($phone_number)) { array_push($errors, "Phone number is required"); }
  if (strlen($phone_number)<10 && strlen($phone_number)>12) { array_push($errors, "Bad phone number length"); }
  if ($phone_number{0}!='0') { array_push($errors, "Phone number must start with number 0!"); }
  if(!ctype_digit($phone_number)){
    array_push($errors, "Invalid characters in phone number");
  }
  if (empty($name)) { array_push($errors, "Name is required"); }
  #if (empty($password_1)) { array_push($errors, "Password is required"); }
  if (strlen($password_1)<4) { array_push($errors, "Password is too short"); }
  if ($password_1 != $password_2) {
  array_push($errors, "The two passwords do not match");
  }

  $user_check_query = "SELECT * FROM customer WHERE phone_number='$phone_number' LIMIT 1";
  $result = mysqli_query($link, $user_check_query) or die(mysqli_error($link));
  $user = mysqli_fetch_assoc($result);

  if ($user) { // if user exists
    if ($user['phone_number'] === $phone_number) {
      array_push($errors, "An account with the associated phone number already exists");
    }
  }

  if (count($errors) == 0) {

    $query = "INSERT INTO customer (phone_number, password, name) 
          VALUES('$phone_number', '$password_1', '$name')";
    mysqli_query($link, $query) or die(mysqli_error($link));
    $_SESSION['success'] = "Account is created successfully. Please try to login.";
    header('location: index.php');
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>SH Restaurant</title>
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
    <link rel ="stylesheet" href="css/restaurant.css">
</head>
<body>
	<ul>
      <li id="courseman"><a href="index.php">SH Restaurant</a></li>
  		<li><a href="menu.php">Menu</a></li>
  		<li><a href="login.php">Login</a></li>
      <li><a href="create_order.php">Order food now!</a></li>
      <li><a href="my_order.php">Your orders</a></li>
	</ul>

  <div style="padding: 50px"></div>

  <div class="header">
    <h2>Register</h2>
  </div>
  
  <form method="post" action="register.php">
    <?php include('db/errors.php'); ?>
    <div class="input-group">
      <label>Phone Number</label>
      <input type="text" name="phone_number" value="">
    </div>
    
    <div class="input-group">
      <label>Password</label>
      <input type="password" name="password_1">
    </div>
    <div class="input-group">
      <label>Confirm password</label>
      <input type="password" name="password_2">
    </div>
    <div class="input-group">
      <label>Name</label>
      <input type="text" name="name">
    </div>
    <div class="input-group">
      <button type="submit" class="btn" name="reg_customer">Register</button>
    </div>
    <p>
      Already a member? <a href="login.php">Sign in</a>
    </p>
  </form>

  <br>

  <div>
    <h2>Guidelines</h2>
    <form> 
        <textarea rows="12" cols="90" readonly>
            -Phone number must be local (must start with 0, must be purely numerical and must have length of 10 or 11 digits)

            -Password must have a minimum length of 4.

            -Repeated password must match the original password.

            -Your phone number will be used for login and order confirmation, so please use your real information.
        </textarea>
    </form>
  </div>

</body>
</html>