<?php 
if(!isset($_SESSION)){
    session_start();
}
if(isset($_SESSION['customer_phonenum'])){
    echo '<br>';
    echo '<br>';
    echo '<br>';
    echo '<br>';
    echo '<br>';
    echo '<h2> Hello, '.$_SESSION['customer_name'].'</h2>';
    echo '<h2> with phone number '.$_SESSION['customer_phonenum'].'</h2>';
}
else{
    $_SESSION['success']= "Please login to order.";
    header("location: index.php");
    exit;
}

if(isset($_SESSION['error'])){

    echo '<br>';
    echo '<br>';
    echo '<h3>'.$_SESSION['error'].'</h3>';
    unset($_SESSION['error']);
}



if($_SESSION['banned']==1){
    $_SESSION['success']= "You have been banned from ordering. Send us a heartfelt apology at 0123456789 and we will forgive you <3";
    header("location: index.php");
    exit;
}
else{
    require_once "db/connect.php";

    $cid= $_SESSION['customer_id'];
    // $ban_check= "SELECT banned FROM customer WHERE id= $cid";
    // $ban_result= mysqli_query($link, $ban_check) or die(mysqli_error($link));
    // while($row = mysqli_fetch_array($ban_result)){
    //   if($row['banned']==1){
    //     $_SESSION['success']= "You have been banned from ordering. Send us a heartfelt apology at 0123456789 and we will forgive you <3";
    //     header("location: index.php");
    //     exit;
    //   }
    // }

    $query = "SELECT banned, unfinished_orders FROM customer WHERE id= $cid";
    $result= mysqli_query($link, $query) or die(mysqli_error($link));
    while($row = mysqli_fetch_array($result)){
      if($row['unfinished_orders']>0){
        $_SESSION['success']= "You already have an ongoing order. Please wait for the order to be completed before making new orders.";
        header("location: index.php");
        exit;
      }
      else if($row['banned']==1){
        $_SESSION['success']= "You have been banned from ordering. Send us a heartfelt apology at 0123456789 and we will forgive you <3";
        header("location: index.php");
        exit;        
      }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>SH Restaurant</title>
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
    <link rel ="stylesheet" href="css/restaurant.css">
</head>
<body>
	<ul>
      <li id="courseman"><a href="index.php">SH Restaurant</a></li>
  		<li><a href="menu.php">Menu</a></li>
  		<li><a href="login.php">Login</a></li>
      <li><a href="create_order.php">Order food now!</a></li>
      <li><a href="my_order.php">Your orders</a></li>
      <?php
      if(isset($_SESSION['loggedin'])){
        echo <<< HERE
        <li id="logout"><a href="logout.php">Logout</a></li>
        HERE;
      }
      ?>
	</ul>
	<h2>"Order food"</h2>
  <div>
    <table>
      <thead>
        <tr>
          <th hidden>Order this?</th>
          <th>Name</th>
          <th>Item Price</th>
          <th>Description</th>
          <th>Image</th>
          <th>Quantity to order? (Max 10)</th>
        </tr>
      </thead>

      <tbody>
        <?php
        $result = mysqli_query($link, "SELECT * FROM menu_item where in_stock=1;");
        echo <<< HERE
            <form method="post" action="review_order.php">
        HERE;
        while($row = mysqli_fetch_array($result)){
          if($row["image"]!=null)
          {
            echo '<tr><td hidden><input type="checkbox" name="checkbox[]" value="'.$row["id"].'" id="checkbox" hidden checked></td>';
            echo nl2br('<td>'.$row["name"].'</td><td>'.$row["price"].'</td><td>'.$row["description"].'</td>'.'<td><img class="img" src="data:image;base64,'.$row["image"].'"></td>');
            echo
            '<td>
                <input type="number" class="form-control" min="0" max="10" value="0"  name="quantity[]">
            </td>';                      
            echo '</tr>';
          }
          else
          {
            echo '<tr><td hidden><input type="checkbox" name="checkbox[]" value="'.$row["id"].'" id="checkbox" hidden checked></td>';
            echo nl2br('<td>'.$row["name"].'</td><td>'.$row["price"].'</td><td>'.$row["description"].'</td><td>'.'Not Available'.'</td>');
            echo
            '<td>
                <input type="number" class="form-control" min="0" max="10" value="0" name="quantity[]">
            </td>';                        
            echo '</tr>';
          }

        }
        ?>
      </tbody>
    </table>
  </div>
  <?php
    echo <<< HERE
        <button type="submit" class="btn" name="submit_order">Create order</button>
        </form>
    HERE;
  ?>
</body>
</html>