<?php
if(!isset($_SESSION)){
 session_start();
}

if(!isset($_SESSION['admin_username'])){
    $_SESSION['success']= "Nice breach attempt";
    header("location: index.php");
    exit;
}

if(isset($_SESSION['ban_status'])){
    echo '<br>';
    echo '<br>';
    echo '<h3>'.$_SESSION['ban_status'].'</h3>';
    unset($_SESSION["ban_status"]);
}

require_once "db/connect.php";


if(isset($_POST['commit_ban'])){
    $cust_id = mysqli_real_escape_string($link, $_POST['cust_id']);

    $query = "UPDATE customer SET banned= NOT banned WHERE id= $cust_id";
    mysqli_query($link, $query) or die(mysqli_error($link));
    $_SESSION['ban_status'] = "Change commited";
    header('location: manage_customers.php');
    exit;
}




?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>SH Restaurant</title>
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
    <link rel ="stylesheet" href="css/restaurant.css">
</head>
<body>
  <ul>
      <li id="courseman"><a href="admin.php">SH Restaurant</a></li>
      <li><a href="add_item.php">Add menu item</a></li>
      <li><a href="manage_menu.php">Manage: menu</a></li>
      <li><a href="manage_orders.php">orders</a></li>
      <li><a href="manage_customers.php">customers</a></li>
      <?php
      if(isset($_SESSION['loggedin'])){
        echo <<< HERE
        <li id="logout"><a href="logout.php">Logout</a></li>
        HERE;
      }
      ?>
  </ul>
  <div style="padding: 50px"></div>
  <h2>Manage customers</h2>
  <div>
    <table>
      <thead>
        <tr>
          <th>Phone Number</th>
          <th>Name</th>
          <th>Completed Orders</th>
          <th>Unfinished Orders</th>
          <th>Failed Orders</th>
          <th>Is Banned?</th>
          <th>Ban/ Unban?</th>
        </tr>
      </thead>

      <tbody>
        <?php
        $result = mysqli_query($link, "SELECT * FROM customer ORDER BY failed_orders DESC;");
        while($row = mysqli_fetch_array($result)){
          $is_banned="";
          if($row["banned"]==1) $is_banned= "Yes";
          else $is_banned= "No";

          echo '<tr><td>'.$row["phone_number"].'</td><td>'.$row["name"].'</td><td>'.$row["completed_orders"].'</td><td>'.$row["unfinished_orders"].'</td><td>'.$row["failed_orders"].'</td><td>'.$is_banned.'</td>';
          echo "<td><form action='manage_customers.php' method='POST'><input type='hidden' name='cust_id' value='".$row["id"]."'/><input type='submit' name='commit_ban' value='Ban/ Unban' /></form></td></tr>";                      
        }
        ?>
      </tbody>
    </table>

<!--     <div style="padding: 50px"></div>

    <div>
    <form> 
        <textarea rows="2" cols="150" readonly>
            For Ban Status, 0 means False/ Not Banned and 1 means True/ Banned
        </textarea>
    </form>
    </div> -->
  </div>
</body>
</html>