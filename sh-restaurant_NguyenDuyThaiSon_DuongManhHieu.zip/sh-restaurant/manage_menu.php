<?php

if(!isset($_SESSION)){
 session_start();
}

if(!isset($_SESSION['admin_username'])){
    $_SESSION['success']= "Nice breach attempt";
    header("location: index.php");
    exit;
}

if(isset($_SESSION['toggle_status'])){
    echo '<br>';
    echo '<br>';
    echo '<h3>'.$_SESSION['toggle_status'].'</h3>';
    unset($_SESSION["toggle_status"]);
}


require_once "db/connect.php";

if(isset($_POST['commit_toggle'])){
    $item_id = mysqli_real_escape_string($link, $_POST['item_id']);

    $query = "UPDATE menu_item SET in_stock= NOT in_stock WHERE id= $item_id";
    mysqli_query($link, $query) or die(mysqli_error($link));
    $_SESSION['toggle_status'] = "Toggled availability";
    header('location: manage_menu.php');
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>SH Restaurant</title>
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
    <link rel ="stylesheet" href="css/restaurant.css">
</head>
<body>
  <ul>
      <li id="courseman"><a href="admin.php">SH Restaurant</a></li>
      <li><a href="add_item.php">Add menu item</a></li>
      <li><a href="manage_menu.php">Manage: menu</a></li>
      <li><a href="manage_orders.php">orders</a></li>
      <li><a href="manage_customers.php">customers</a></li>
      <?php
      if(isset($_SESSION['loggedin'])){
        echo <<< HERE
        <li id="logout"><a href="logout.php">Logout</a></li>
        HERE;
      }
      ?>
  </ul>
  <div style="padding: 50px"></div>
  <h2>Manage menu items' availability</h2>
  <div>
    <table>
      <thead>
        <tr>
          <th>Name</th>
          <th>Item Price</th>
          <th>Description</th>
          <th>Image</th>
          <th>Is available?</th>
          <th>Toggle availability?</th>
        </tr>
      </thead>

      <tbody>
        <?php
        $result = mysqli_query($link, "SELECT * FROM menu_item ORDER BY name;");
        while($row = mysqli_fetch_array($result)){
          $availability= "";
          if($row["in_stock"]==1){
            $availability= "Yes";
          }
          else $availability= "No";
          if($row["image"]!=null)
          {
            echo nl2br('<tr><td>'.$row["name"].'</td><td>'.$row["price"].'</td><td>'.$row["description"].'</td>'.'<td><img class="img" src="data:image;base64,'.$row["image"].'"></td><td>'.$availability.'</td>');
            echo "<td><form action='manage_menu.php' method='POST'><input type='hidden' name='item_id' value='".$row["id"]."'/><input type='submit' name='commit_toggle' value='Toggle' /></form></td>";                         
            echo '</tr>';
          }
          else
          {
            echo nl2br('<tr><td>'.$row["name"].'</td><td>'.$row["price"].'</td><td>'.$row["description"].'</td><td>'.'Not Available'.'</td><td>'.$availability.'</td>');
            echo "<td><form action='manage_menu.php' method='POST'><input type='hidden' name='item_id' value='".$row["id"]."'/><input type='submit' name='commit_toggle' value='Toggle' /></form></td>";
            echo '</tr>';
          }

        }
        ?>
      </tbody>
    </table>
  </div>
</body>
</html>