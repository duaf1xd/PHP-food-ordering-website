<?php

require_once "db/connect.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>SH Restaurant</title>
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
    <link rel ="stylesheet" href="css/restaurant.css">
</head>
<body>
  <ul>
      <li id="courseman"><a href="index.php">SH Restaurant</a></li>
      <li><a href="menu.php">Menu</a></li>
      <li><a href="login.php">Login</a></li>
      <li><a href="create_order.php">Order food now!</a></li>
      <li><a href="my_order.php">Your orders</a></li>
      <?php
      if(isset($_SESSION['loggedin'])){
        echo <<< HERE
        <li id="logout"><a href="logout.php">Logout</a></li>
        HERE;
      }
      ?>
  </ul>
  <div style="padding: 50px"></div>
  <h1>Le Menu</h1>
  <div>
    <table>
      <thead>
        <tr>
          <th>Name</th>
          <th>Item Price</th>
          <th>Description</th>
          <th>Image</th>
        </tr>
      </thead>

      <tbody>
        <?php
        $result = mysqli_query($link, "SELECT * FROM menu_item WHERE in_stock=1 ORDER BY name;");
        while($row = mysqli_fetch_array($result)){
          if($row["image"]!=null)
          {
            echo nl2br('<tr><td>'.$row["name"].'</td><td>'.$row["price"].'</td><td>'.$row["description"].'</td>'.'<td><img class="img" src="data:image;base64,'.$row["image"].'"></td>');                      
            echo '</tr>';
          }
          else
          {
            echo nl2br('<tr><td>'.$row["name"].'</td><td>'.$row["price"].'</td><td>'.$row["description"].'</td><td>'.'Not Available'.'</td>');                      
            echo '</tr>';
          }

        }
        ?>
      </tbody>
    </table>
  </div>
</body>
</html>