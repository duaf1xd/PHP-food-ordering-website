<?php 
if(!isset($_SESSION)){
 session_start();
}

if(!isset($_SESSION['admin_username'])){
    $_SESSION['success']= "Nice breach attempt";
    header("location: index.php");
    exit;
}

if(isset($_SESSION['add_item_status'])){
    echo '<br>';
    echo '<br>';
    echo '<h2>'.$_SESSION['add_item_status'].'</h2>';
    unset($_SESSION["add_item_status"]);
}
$errors = array(); 

require_once "db/connect.php";

if(isset($_POST['submit'])){
  
  $item_name= mysqli_real_escape_string($link, $_POST['item_name']);
  $description= mysqli_real_escape_string($link, $_POST['description']);
  $price= mysqli_real_escape_string($link, $_POST['price']);
  $image= null;
  echo '<h2>'.' HELPPPPPPP '.'</h2>';
  if(getimagesize($_FILES['image']['tmp_name'])==FALSE){
    // array_push($errors, "Image upload failed");
  }
  else{
    $image= base64_encode(file_get_contents(addslashes($_FILES['image']['tmp_name'])));
  }

  if (count($errors) == 0) {

    $query = "INSERT INTO menu_item (name, description, price, image) 
          VALUES('$item_name', '$description', '$price', '$image')";
    mysqli_query($link, $query) or die(mysqli_error($link));
    $_SESSION['add_item_status'] = "Item is added";
    header('location: add_item.php');
  }

}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>SH Restaurant</title>
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
    <link rel ="stylesheet" href="css/restaurant.css">
</head>
<body>
	<ul>
      <li id="courseman"><a href="admin.php">SH Admin</a></li>
      <li><a href="add_item.php">Add menu item</a></li>
      <li><a href="manage_menu.php">Manage: menu</a></li>
      <li><a href="manage_orders.php">orders</a></li>
      <li><a href="manage_customers.php">customers</a></li>
      <?php
      if(isset($_SESSION['loggedin'])){
        echo <<< HERE
        <li id="logout"><a href="logout.php">Logout</a></li>
        HERE;
      }
      ?>
	</ul>
	<div style="padding: 50px"></div>
	<h1>Add a new menu item</h1>
  <form method="post" action="add_item.php" enctype="multipart/form-data">
    <?php include('db/errors.php'); ?>
    <div class="input-group">
      <label>Item Name</label>
      <input type="text" name="item_name" value="">
    </div>
    
    <div class = "input-group">
      <label for="description">Description</label>
      <br>
      <textarea name ="description" rows="10" cols="50" placeholder="Enter dish description here..." required></textarea>
    </div>
    <div class="input-group">
      <label>Price</label>
      <input type="number" step="0.01" min="0" name="price">
    </div>
    <div class="input-group">
      <label>Image</label>
      <input type="file" name="image">
    </div>
    <div class="input-group">
      <button type="submit" class="btn" name="submit">Confirm add item</button>
    </div>

  </form>
</body>
</html>