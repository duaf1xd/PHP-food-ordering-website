<?php

if(!isset($_SESSION)){
    session_start();
}
if(!isset($_SESSION['admin_username'])){
    $_SESSION['success']= "Nice breach attempt";
    header("location: index.php");
    exit;
}


require_once "db/connect.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>SH Restaurant</title>
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
    <link rel ="stylesheet" href="css/restaurant.css">
</head>
<body>
  <ul>
      <li id="courseman"><a href="admin.php">SH Restaurant</a></li>
      <li><a href="add_item.php">Add menu item</a></li>
      <li><a href="manage_menu.php">Manage: menu</a></li>
      <li><a href="manage_orders.php">orders</a></li>
      <li><a href="manage_customers.php">customers</a></li>
      <?php
      if(isset($_SESSION['loggedin'])){
        echo <<< HERE
        <li id="logout"><a href="logout.php">Logout</a></li>
        HERE;
      }
      ?>

  </ul>
  <div style="padding: 50px"></div>
  <h2>Entire orders history</h2>
  <div>
    <table>
      <thead>
        <tr>
          <th>Order Details</th>
          <th>Status</th>
          <th>Time initialized</th>
        </tr>
      </thead>

      <tbody>
        <?php
        $result = mysqli_query($link, "SELECT * FROM request ORDER BY timestamp DESC;");
        while($row = mysqli_fetch_array($result)){
          $status="";
          if($row["available_status"]==1){
            $status="Ongoing";
          }
          else{
            $status="Finished";
          }
          echo nl2br('<tr><td>'.$row["request_details"].'</td><td>'.$status.'</td><td>'.$row["timestamp"].'</td></tr>');                      
        }
        ?>
      </tbody>
    </table>
  </div>

  <p>
      <a href="manage_orders.php">View ongoing orders only</a>
  </p>

</body>
</html>