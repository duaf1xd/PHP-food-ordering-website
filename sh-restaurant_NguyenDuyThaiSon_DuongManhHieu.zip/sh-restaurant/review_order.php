<?php 
if(!isset($_SESSION)){
    session_start();
}
if(!isset($_SESSION['customer_phonenum'])){
    $_SESSION['success']= "Please login to order.";
    header("location: index.php");
    exit;
}
require_once "db/connect.php";
if($_SESSION['banned']==1){
    echo '<h2> You have been banned from ordering. Send us a heartfelt apology at 0123456789 and we will forgive you <3 </h2>';
}
else{
    $cid= $_SESSION['customer_id'];
    $query = "SELECT banned, unfinished_orders FROM customer WHERE id= $cid";
    $result= mysqli_query($link, $query) or die(mysqli_error($link));
    while($row = mysqli_fetch_array($result)){
      if($row['unfinished_orders']>0){
        $_SESSION['success']= "You already have an ongoing order. Please wait for the order to be completed before making new orders.";
        header("location: index.php");
        exit;
      }
      else if($row['banned']==1){
        $_SESSION['success']= "You have been banned from ordering. Send us a heartfelt apology at 0123456789 and we will forgive you <3";
        header("location: index.php");
        exit;        
      }
    }
}

if(isset($_POST['submit_order'])){
    

    $selected_items= $_POST['checkbox'];

    echo '<br>';
    echo '<br>';
    echo '<br>';
    echo '<br>';
    echo '<br>';
    // if(count($selected_items)==0){
    //     $_SESSION['error']="Please select at least one item";
    //     header("location: create_order.php");
    //     exit;
    // }
    // else{
    //     for($i= 0; $i< count($selected_items); $i++){
    //         echo '<p> This is selected columns '.$selected_items[$i].'</p>';
    //     }
    // }

    $quantity= $_POST['quantity'];
    if(count($quantity)==0){
        $_SESSION['error']="Fill in at least one quantity...";
        header("location: create_order.php");
        exit;
    }
    else{
        $deleted_items=0;
        for($i= 0; $i< count($quantity); $i++){
            if($quantity[$i]==0 || is_null($quantity[$i])){
                \array_splice($selected_items, $i-$deleted_items, 1);
                $deleted_items++;
            }
            // echo '<p> This is selected quantities '.$quantity[$i].'</p>';
        }
    }
    // for($i= 0; $i< count($selected_items); $i++){
    //     echo '<p> This is selected columns '.$selected_items[$i].'</p>';
    // }
    $pruned_quantities= array();
    for($i= 0; $i< count($quantity); $i++){
        if(!is_null($quantity[$i]) && $quantity[$i]>0 ){
            array_push($pruned_quantities, $quantity[$i]);
        }   
    }
    // for($i= 0; $i< count($pruned_quantities); $i++){
    //     echo '<p> This is pruned_quantity '.$pruned_quantities[$i].'</p>';
    // }
    $total_price= 0;
    $order_content="Dear ".$_SESSION['customer_name']." at phone number: "
    .$_SESSION['customer_phonenum']."\r\n"."Please kindly verify your order:"."\r\n";

    // echo nl2br('<p>'.$order_content.'</p>');


}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>SH Restaurant</title>
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
    <link rel ="stylesheet" href="css/restaurant.css">

</head>
<body>
	<ul>
      <li id="courseman"><a href="index.php">SH Restaurant</a></li>
  		<li><a href="menu.php">Menu</a></li>
  		<li><a href="login.php">Login</a></li>
        <li><a href="create_order.php">Order food now!</a></li>
        <li><a href="my_order.php">Your orders</a></li>
        <?php
        if(isset($_SESSION['loggedin'])){
            echo <<< HERE
            <li id="logout"><a href="logout.php">Logout</a></li>
            HERE;
        }
        ?>
	</ul>
	<div style="padding: 50px"></div>
	<h2>"Review your order"</h2>
    <?php
    for($i=0; $i<count($selected_items); $i++){
        $param= $selected_items[$i];
        $query = "SELECT * FROM menu_item WHERE id= $param";
        $result= mysqli_query($link, $query) or die(mysqli_error($link));
        while($row = mysqli_fetch_array($result)){
            // echo '<p> This is itemname got back '.$row['name'].'</p>';
            $order_content.=$pruned_quantities[$i];
            $order_content.="x ";
            $order_content.=$row['name'];
            $order_content.=" (";
            $order_content.=$row['price'];
            $order_content.="VND each) ";
            $row_price= $row['price']*$pruned_quantities[$i];
            $total_price+= $row_price;
            $order_content.=" for ";
            $order_content.=$row_price;
            $order_content.=" VND";
            $order_content.="\r\n";
        }
    }


    // echo nl2br('<h3>'.$order_content.'</h3>');
    // echo nl2br('<h3>The total price is '.$total_price.' VND</h3>');
    // echo nl2br('<h3>Would you like to finalize this order?</h3>');

    $order_content.="The total price is: ";
    $order_content.=$total_price;
    $order_content.=" VND";
    $order_content.="\r\n";
    $order_content.="Would you like to finalize this order?";

    echo nl2br('<h3>'.$order_content.'</h3>');
    ?>

    <form method= 'POST' action= 'save_order.php'> 
        <textarea rows="12" cols="90" name="ticket" hidden readonly>
            <?php echo $order_content ?>
        </textarea>


        <?php
        if($total_price>0){
            echo <<< HERE
            <button type="submit" id="add" name="save_ticket">Place order</button>
            HERE;
        }
        else{
            echo '<h3>This is an invalid attempt to create an order!</h3>';
        }
        ?>
    </form>
</body>
</html>