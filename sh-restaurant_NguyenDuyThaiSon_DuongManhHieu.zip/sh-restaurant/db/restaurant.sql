CREATE DATABASE php_restaurant;
USE php_restaurant;
CREATE TABLE manager (
  `id` INT NOT NULL UNIQUE AUTO_INCREMENT,
  `username` VARCHAR(64) NOT NULL UNIQUE,
  `password` VARCHAR(64) NOT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_unicode_ci;

INSERT INTO manager (`id`, `username`, `password`) VALUES (NULL, 'admin', 'admin');
INSERT INTO manager (`id`, `username`, `password`) VALUES (NULL, 'duaf1xd', 'duaf1xd');

CREATE TABLE customer (
  `id` INT NOT NULL UNIQUE AUTO_INCREMENT,
  `phone_number` VARCHAR(15) NOT NULL UNIQUE,
  `password` VARCHAR(64) NOT NULL,
  `name` VARCHAR(64) NOT NULL,
  `completed_orders` int DEFAULT 0,
  `unfinished_orders` int DEFAULT 0,
  `failed_orders` int DEFAULT 0,
  `banned` boolean DEFAULT 0,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_unicode_ci;

INSERT INTO customer(`id`, `phone_number`, `password`, `name`)
VALUES (NULL, '0862021299', 'duaf1xd', 'Nguyen Duy Thai Son');

CREATE TABLE menu_item (
  `id` INT NOT NULL UNIQUE AUTO_INCREMENT,
  `name` VARCHAR(164) NOT NULL UNIQUE,
  `description` VARCHAR(200) NOT NULL,
  `price` FLOAT(11,3) NOT NULL,
  `image` LONGBLOB,
  `in_stock` boolean NOT NULL DEFAULT TRUE,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_unicode_ci;

INSERT INTO menu_item(`id`, `name`, `description`, `price`, `image`)
VALUES (NULL, 'Nepcake', 'A delicious Nepcake that comes with free Neps', 25000.59, NULL);


CREATE TABLE request (
  `id` INT NOT NULL UNIQUE AUTO_INCREMENT,
  `request_details` VARCHAR(1000) NOT NULL UNIQUE,
  `available_status` boolean NOT NULL DEFAULT TRUE,
  `timestamp` timestamp NOT NULL,
  `customer_id` int NOT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (customer_id) REFERENCES customer(id))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_unicode_ci;
