IMPORTANT:

SQL script for database is in db/restaurant.sql.

Admin routes are hidden behind /admlg.php.

( http://localhost/sh-restaurant/admlg.php ) if you are using XAMPP and placed the sh-restaurant folder into htdocs.

After logging in with admin credentials (ID: admin, PW: admin), you can add new items to the menu (using images of your own or some included in "test" folder) to then test out the order functions in the customers' routes.

Thank you for reading!