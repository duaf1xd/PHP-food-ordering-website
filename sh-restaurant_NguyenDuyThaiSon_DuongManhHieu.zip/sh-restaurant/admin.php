<?php 
if(!isset($_SESSION)){
    session_start();
}
if(!isset($_SESSION['admin_username'])){
    $_SESSION['success']= "Nice breach attempt";
    header("location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>SH Restaurant</title>
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
    <link rel ="stylesheet" href="css/restaurant.css">
</head>
<body>
	<ul>
      <li id="courseman"><a href="admin.php">SH Admin</a></li>
  		<li><a href="add_item.php">Add menu item</a></li>
      <li><a href="manage_menu.php">Manage: menu</a></li>
      <li><a href="manage_orders.php">orders</a></li>
  		<li><a href="manage_customers.php">customers</a></li>
      <?php
      if(isset($_SESSION['loggedin'])){
        echo <<< HERE
        <li id="logout"><a href="logout.php">Logout</a></li>
        HERE;
      }
      ?>
	</ul>
	<div style="padding: 50px"></div>
	<h1>"Welcome to the Admin Page"</h1>
</body>
</html>