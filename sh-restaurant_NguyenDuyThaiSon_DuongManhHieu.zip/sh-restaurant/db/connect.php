<?php
if(!isset($_SESSION)){
    session_start();
}
$servername = "localhost";
$server_user = "root";
$server_pass = "";
$dbname = "php_restaurant";
// $name = $_SESSION['name'];
// $role = $_SESSION['role'];
$link = new mysqli($servername, $server_user, $server_pass, $dbname);

if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
?>